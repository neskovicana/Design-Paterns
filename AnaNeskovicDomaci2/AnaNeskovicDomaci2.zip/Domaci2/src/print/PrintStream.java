package print;

public interface PrintStream {
	public void println(String s);
}
